var config = {
    paths: {
        'sold_notification': 'TD_SoldNotification/js/sold_notification'
    }
};
